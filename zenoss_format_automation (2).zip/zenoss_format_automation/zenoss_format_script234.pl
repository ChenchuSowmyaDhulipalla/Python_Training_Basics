#!/usr/bin/perl

my $flen=0;
my $rlen=0;

open(FH,"$ARGV[0]"); 			 
if($ARGV[0] ne "")
{
@File=<FH>;
close FH;
$flen=@File;

foreach $file(@File)
{
	@lin1=split("\t",$file);
	$len=@lin1;  			
	$rlen=$len-3;
	next;
}
if($ARGV[1] ne "")
{
open(FF,">$ARGV[1]");   		

for($i=1;$i<$flen;$i++)	  		
	{
		$File[$i]=~s/\s+$//;
		@each_row=split("\t",$File[$i]);
		$len1=@each_row;
		$b="$each_row[0] zAdvancedLogSearches='[";
		$c="]'";
		
		for($j=3;$j<$len1;)	
        	{
			#chomp(@each_row);
			$string="{\"advanced_log_search_name\":\"$each_row[$j]\",\"log_file\":\"$each_row[2]\",\"search_pattern\":\"$each_row[$j+1]\",\"zero_pattern\":\"\",\"search_type\":\"String\"},";
			$b=$b.$string;
			$j=$j+2;
 		       	
		}
		$b =~ s/,$//;
		print FF "$b$c\n\n";
}
close(FF);
print "please check the output of $ARGV[0] in $ARGV[1]\n";

}
else
{
print "please enter the output file name\n";
}
}
else
{
print "please pass file as argument\n";
}

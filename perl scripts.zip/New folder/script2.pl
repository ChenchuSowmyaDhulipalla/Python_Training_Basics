#!/usr/bin/perl

$file1="/root/scripts/Script_2_File1.txt";
$file2="/root/scripts/Script_2_File2.txt";
$file3="/root/scripts/Scrip2_Final_Results.txt";

`dos2unix $file1`;
`dos2unix $file2`;
`dos2unix $file3`;

open(FH,$file1);
@arr1=<FH>;
close FH;

open(FH,$file2);
@arr2=<FH>;
close FH;

open(FH,$file3);
@arr3=<FH>;
close FH;

open(FH,">out2.csv");

foreach $arr(@arr1)
{
$line = `echo "$arr" | awk -F"\/\/" '{print \$2}'`;chomp($line);chomp($line);
$line1 = `echo "$line" | awk -F":" '{print \$1}'`;chomp($line1);chomp($line1);
$inst = `echo "$line" | awk -F"\/" '{print \$2}'`;chomp($inst);chomp($inst);
$l1 = uc $line1;chomp($l1);

for($i=0;$i<@arr2;$i++)
{
	chomp($arr2[$i]);
	$arr2[$i]=~s/\./\ /g;
	$a2 = uc $arr2[$i];
	if(index($a2,$l1) != -1) 
	{
		for($j=0;$j<@arr3;$j++)
		{
		chomp($arr3[$j]);
			$a3 = $arr3[$j];
			$a3 =~ s/\// /g;chomp($a3);chop($a3);
				do{
				$upass= `echo \'$arr3[$j]\' | awk -F":" '{print \$3":"\$4}'`;
				chomp($line);chomp($upass);
				$fline = "$line" . "$upass";
				print FH "$fline\n";last;
			}while($inst =~ m/a3/g);
		}

		last;
	}
}
}
close FH;

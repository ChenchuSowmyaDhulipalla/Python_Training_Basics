#!/usr/bin/perl
##########################################################################
##     Convert Oracle Output file into Zenoss Format
#########################################################################


  use strict;
  use warnings;
  use Text::CSV;

  my $file = "Monitor_Report4p_DB2_dbout.txt";
  my $ofile= "out.csv"; 
  my $nfile= "out1.csv"; 

open my $fh, "<", $file or die "$file: $!";
open my $outfile, ">>", $ofile or die "Cannot open: $!"; 

  my $csv = Text::CSV->new ({
      binary    => 1, # Allow special character. Always set this
      auto_diag => 1, # Report irregularities immediately
      });

while (my $row = $csv->getline ($fh))
{
my $f1= $row->[1];
my @strings= $f1=~ /([A-Za-z]+[\d]+?\w+):/g;


foreach my $res (@strings)
{
printf $outfile "$res\n";
}

}

close $fh;
close $outfile;

`sort -u $ofile > $nfile`;
